from django.db import models

# Create your models here.


class movie_Database(models.Model):
    
    movie_id=models.IntegerField(primary_key=True);
    movie_name=models.CharField(max_length=100)


    def __srt__(self):
        return self.id