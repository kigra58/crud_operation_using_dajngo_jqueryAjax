//function getData(){

//   output=""
   
//    $.ajax({
//      url:"{% url '' %}",
//      method:"GET",
//      data:
//      success:function(data,status){
//            console.log(data);
           
//            for(i=0;i<data.length; i++){
//             output+=" <tr> <td>"+ data[i].id + "</td> <td>"+ data[i].movie_name + "</td> <td> <button data-sid="+ data[i].id +">Edit</button> <button  data-sid="+ data[i].id +" >Delete</button>  </td> </tr> "
//           }
//           $("#tbody").html(output)
//           $("#form")[0].reset();
//      }
//    })
 //}






 
// $("#deleteBtn").click(function(){
    
//     $.ajax({
//       url:"{% url 'index' %}",
//       method:"DELETE",
//       data:
//       success:function(data,status){
//           console.log(status)
//       }
//     })
// });


// $("#updateBtn").click(function(){
    
//      $.ajax({
//        url:"{% url 'index' %}",
//        method:"PUT",
//        data:
//        success:function(data,status){
//          console.log(data)
//        }
//      })
// })
     








// $("#submitBtn").click(function(e){

//     e.preventDefault();

//     console.log("summit button clicked !")

//     let movie_id=$("#movie_id").val();
//     let movie_name=$("#movie_name").val();

//     mydata={ movie_id:movie_id,movie_name:movie_name }
//     //console.log(mydata);

//     $.ajax({
//       url:" {% url 'insert' %} ",
//       method:"POST",
//       data:mydata,
//       dataType:"json",
//       success:function(data){
//           console.log(data.status); 
            //  $("#submitBtn").click(function(){
            //      $("#my2").toast('show');
            //    });
                
//           $("#form")[0].reset(); 
            
//       }
//     });

// });







