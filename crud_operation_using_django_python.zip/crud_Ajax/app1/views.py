from django.shortcuts import render
from .models import *
from django.http import JsonResponse
from django.core import serializers
from django.views.decorators.csrf import csrf_exempt

# Create your views here.
@csrf_exempt
def index(req):
   
    return render(req,"app1/index.html")

@csrf_exempt
def show(request):
    data1= movie_Database.objects.all()

    data=serializers.serialize('json',data1)
    
    return JsonResponse({'data':data} )


# inser button se dono kam kra rahe hai 
    

@csrf_exempt
def insert(request):
    
    if request.method=='POST':
        id1=request.POST['movie_id']
        movie_name=request.POST['movie_name']
        if(movie_Database.objects.filter(pk=id1)):
            movie_Database(movie_name=movie_name)
        
        movie_Database(movie_id=id1, movie_name=movie_name).save()
        return JsonResponse({'status':'save',})
        
    else:
        return JsonResponse({'status':0})




@csrf_exempt
def delete(request):

    if request.method=="POST":

        id=request.POST['sid']
        #print(id)
        movie_Database.objects.filter(pk=id).delete()

        return JsonResponse({'status':1})
    else:
        return JsonResponse({'status':0})






def update(request):

        id=request.GET['sid']
    
        for data in movie_Database.objects.filter(pk=id):
            data1=data.movie_id
            data2=data.movie_name
            #print(data1)
            #print(data2)

        
        return JsonResponse({'data1':data1,'data2':data2})




@csrf_exempt
def search(request):
    query=request.POST['search']

    data1=movie_Database.objects.filter(movie_name__icontains=query)
    data=serializers.serialize('json',data1)
    #print(data)

    return JsonResponse({'data':data})